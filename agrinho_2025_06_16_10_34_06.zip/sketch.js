let limg = 612;
let himg =406;
let ximg = 10;
let yimg = 20;
let img;



// Load the image.
function preload () {
  img = loadImage ("images.jpeg");
}

function setup( ) {
   createCanvas(400, 400);
}

function draw( ){
background(img);
    
   //image(img, yimg, himg, limg)
 }
function setup() {
  createCanvas(400, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  background("lightgreen");
  textSize(40);
  text("🚜", xJogador1, 100);
  text("🌱", xJogador2, 300);
  rect(350, 0, 10, 400);
  xJogador1 += random(5);
  xJogador2 += random(5);

}